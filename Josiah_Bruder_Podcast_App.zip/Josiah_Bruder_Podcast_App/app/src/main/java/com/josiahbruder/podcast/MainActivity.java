package com.josiahbruder.podcast;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.content.Intent;
import android.net.Uri;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import java.util.*;

public class MainActivity extends Activity {
    PodcastView view;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        view = new PodcastView();
        setContentView(view);
    }

    class PodcastView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        int page = 0;
        long splashUntil = System.currentTimeMillis() + 1800;
        Handler handler = new Handler();
        Bitmap[] photos = new Bitmap[4];

        int pink = Color.rgb(255,45,178);
        int blue = Color.rgb(35,190,255);
        int purple = Color.rgb(150,70,255);
        int cyan = Color.rgb(0,245,220);

        PodcastView() {
            super(MainActivity.this);
            photos[0] = load(R.drawable.foto1);
            photos[1] = load(R.drawable.foto2);
            photos[2] = load(R.drawable.foto3);
            photos[3] = load(R.drawable.foto4);
            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(3);
            handler.postDelayed(() -> invalidate(), 100);
        }

        Bitmap load(int id) { return BitmapFactory.decodeResource(getResources(), id); }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            c.drawColor(Color.rgb(5,5,9));
            if (System.currentTimeMillis() < splashUntil) {
                drawSplash(c);
                handler.postDelayed(() -> invalidate(), 80);
                return;
            }
            drawApp(c);
        }

        void text(Canvas c, String s, float x, float y, float size, int color, boolean bold) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            p.setTextSize(size);
            p.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL));
            c.drawText(s, x, y, p);
        }

        void glowRect(Canvas c, float l, float t, float r, float b, int color, float radius) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(12,12,20));
            c.drawRoundRect(l,t,r,b,radius,radius,p);
            stroke.setColor(color);
            stroke.setShadowLayer(18,0,0,color);
            setLayerType(View.LAYER_TYPE_SOFTWARE, stroke);
            c.drawRoundRect(l,t,r,b,radius,radius,stroke);
            stroke.clearShadowLayer();
        }

        void drawSplash(Canvas c) {
            float w=getWidth(), h=getHeight();
            p.setShader(new LinearGradient(0,0,w,h,Color.rgb(4,5,18),Color.rgb(25,4,35),Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,h,p); p.setShader(null);
            text(c,"🎙",w/2-28,h*.36f,54,blue,false);
            text(c,"JOSIAH UND",w/2-125,h*.48f,34,blue,true);
            text(c,"BRUDER",w/2-93,h*.55f,40,pink,true);
            text(c,"PODCAST",w/2-87,h*.61f,28,cyan,true);
            text(c,"75+ FOLGEN",w/2-78,h*.70f,19,Color.WHITE,true);
            text(c,"WIRD GELADEN ...",w/2-86,h*.76f,13,Color.LTGRAY,false);
        }

        void drawHeader(Canvas c) {
            p.setColor(Color.rgb(8,8,16)); p.setStyle(Paint.Style.FILL);
            c.drawRect(0,0,getWidth(),76,p);
            text(c,"☰",22,49,30,Color.WHITE,false);
            text(c,"JOSIAH & BRUDER",62,45,20,Color.WHITE,true);
            text(c,pageTitle(),getWidth()-125,45,13,pink,true);
        }

        String pageTitle() {
            switch(page) {
                case 1:return "FOLGEN";
                case 2:return "BILDER";
                case 3:return "FAKTEN";
                case 4:return "MEHR";
                default:return "START";
            }
        }

        void drawApp(Canvas c) {
            drawHeader(c);
            switch(page) {
                case 1: drawEpisodes(c); break;
                case 2: drawGallery(c); break;
                case 3: drawFacts(c); break;
                case 4: drawMore(c); break;
                default: drawHome(c);
            }
            drawNav(c);
        }

        void drawHome(Canvas c) {
            float w=getWidth();
            drawPhoto(c,photos[0],20,95,w-20,330);
            // dark overlay
            p.setColor(0x99000000); c.drawRect(20,210,w-20,330,p);
            text(c,"JOSIAH UND",40,250,31,Color.WHITE,true);
            text(c,"BRUDER",40,289,38,pink,true);
            text(c,"PODCAST",40,321,24,blue,true);

            glowRect(c,20,350,w-20,420,pink,18);
            text(c,"🎧  75+ FOLGEN",42,392,22,Color.WHITE,true);

            text(c,"Zwei Brüder • Alltag • Unterhaltung",28,455,17,cyan,true);
            text(c,"Hier findest du Folgen, Bilder und Fakten.",28,485,15,Color.LTGRAY,false);

            glowRect(c,20,520,w/2-8,600,blue,18);
            text(c,"SPOTIFY",45,566,18,Color.WHITE,true);
            text(c,"JETZT HÖREN →",45,588,12,blue,true);

            glowRect(c,w/2+8,520,w-20,600,purple,18);
            text(c,"SPREAKER",w/2+28,566,18,Color.WHITE,true);
            text(c,"JETZT HÖREN →",w/2+28,588,12,purple,true);
        }

        void drawEpisodes(Canvas c) {
            text(c,"NEUE FOLGEN",22,115,28,Color.WHITE,true);
            text(c,"75+ Folgen",22,143,16,pink,true);
            String[] titles={"Folge 75 – Neue Folge","Folge 74 – Unser Alltag","Folge 73 – Lustige Momente","Folge 72 – Themen & Stories","Folge 71 – Fragen & Antworten"};
            for(int i=0;i<titles.length;i++){
                float y=165+i*82;
                glowRect(c,18,y,getWidth()-18,y+68,i%2==0?pink:blue,14);
                drawPhoto(c,photos[i%4],28,y+8,92,y+60);
                text(c,titles[i],105,y+30,15,Color.WHITE,true);
                text(c,"▶  ANHÖREN",105,y+53,12,cyan,true);
            }
        }

        void drawGallery(Canvas c) {
            text(c,"BILDERGALERIE",22,115,28,Color.WHITE,true);
            int cols=2; float gap=12, left=18, top=145, cw=(getWidth()-left*2-gap)/2, ch=180;
            for(int i=0;i<photos.length;i++){
                int col=i%cols,row=i/cols;
                float x=left+col*(cw+gap), y=top+row*(ch+gap);
                glowRect(c,x,y,x+cw,y+ch,i%2==0?pink:blue,14);
                drawPhoto(c,photos[i],x+5,y+5,x+cw-5,y+ch-5);
            }
            text(c,"Tipp: Bilder können später mit eigenen Fakten verknüpft werden.",22,top+2*(ch+gap)+20,13,Color.LTGRAY,false);
        }

        void drawFacts(Canvas c) {
            text(c,"FAKTEN ÜBER UNS",22,115,28,Color.WHITE,true);
            String[][] facts={
                {"🎙","Podcast","Josiah und Lukas"},
                {"🎧","Folgen","75+ veröffentlicht"},
                {"💬","Themen","Alltag & Unterhaltung"},
                {"📸","Bilder","Anklickbare Galerie"},
                {"📡","Plattformen","Spotify • Amazon Music • Spreaker"}
            };
            for(int i=0;i<facts.length;i++){
                float y=150+i*92;
                glowRect(c,18,y,getWidth()-18,y+75,i%2==0?purple:cyan,14);
                text(c,facts[i][0],32,y+44,23,Color.WHITE,false);
                text(c,facts[i][1],72,y+31,13,Color.LTGRAY,false);
                text(c,facts[i][2],72,y+55,17,Color.WHITE,true);
            }
        }

        void drawMore(Canvas c) {
            text(c,"MEHR",22,115,28,Color.WHITE,true);
            drawPhoto(c,photos[1],20,140,getWidth()-20,340);
            text(c,"ÜBER JOSIAH & LUKAS",25,375,23,pink,true);
            text(c,"Zwei Brüder mit einem Podcast",25,405,16,Color.WHITE,true);
            text(c,"Kontakt: josiahgassner@gmail.com",25,438,15,cyan,true);

            glowRect(c,20,475,getWidth()-20,545,blue,16);
            text(c,"AMAZON MUSIC  →",42,518,18,Color.WHITE,true);

            glowRect(c,20,565,getWidth()-20,635,pink,16);
            text(c,"E-MAIL SENDEN  →",42,608,18,Color.WHITE,true);
        }

        void drawNav(Canvas c) {
            float y=getHeight()-78, w=getWidth()/5f;
            p.setColor(Color.rgb(8,8,16)); c.drawRect(0,y,getWidth(),getHeight(),p);
            String[] n={"⌂","♫","▣","★","•••"};
            String[] l={"Start","Folgen","Bilder","Fakten","Mehr"};
            for(int i=0;i<5;i++){
                int color=page==i?pink:Color.LTGRAY;
                text(c,n[i],w*i+w/2-8,y+30,22,color,true);
                text(c,l[i],w*i+w/2-18,y+55,11,color,true);
            }
        }

        void drawPhoto(Canvas c, Bitmap b, float l,float t,float r,float bot) {
            if(b==null)return;
            Rect src=new Rect(0,0,b.getWidth(),b.getHeight());
            RectF dst=new RectF(l,t,r,bot);
            c.drawBitmap(b,src,dst,p);
        }

        @Override public boolean onTouchEvent(android.view.MotionEvent e) {
            if(e.getAction()!=MotionEvent.ACTION_UP)return true;
            float x=e.getX(), y=e.getY();
            if(System.currentTimeMillis()<splashUntil)return true;
            float navY=getHeight()-90;
            if(y>=navY){
                int i=(int)(x/(getWidth()/5f));
                if(i>=0&&i<=4){page=i;invalidate();return true;}
            }
            // Platform buttons
            if(page==0 && y>=515 && y<=610){
                if(x<getWidth()/2) open("https://open.spotify.com/");
                else open("https://www.spreaker.com/");
            } else if(page==4 && y>=470 && y<=550) {
                open("https://music.amazon.com/");
            } else if(page==4 && y>=555 && y<=650) {
                Intent mail=new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:josiahgassner@gmail.com"));
                startActivity(mail);
            }
            return true;
        }

        void open(String url){
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch(Exception ignored){}
        }
    }
}
