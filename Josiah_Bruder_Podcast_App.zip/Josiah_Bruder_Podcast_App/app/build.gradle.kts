plugins {
    id("com.android.application")
}

android {
    namespace = "com.josiahbruder.podcast"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.josiahbruder.podcast"
        minSdk = 23
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }
}
