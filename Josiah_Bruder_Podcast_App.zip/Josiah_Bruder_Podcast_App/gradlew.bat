@echo off
echo Open this project in Android Studio and let Android Studio manage the Gradle wrapper.
