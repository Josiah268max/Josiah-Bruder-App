# Josiah und Bruder Podcast – Android-App

Dies ist ein **bearbeitbares Android-Studio-Projekt** für die Podcast-App.

## Enthalten
- Neon-Cool-Design
- Intro beim Start
- 75+ Folgen
- Bildergalerie mit den hochgeladenen Fotos
- Fakten
- Über-uns-/Kontaktbereich
- Buttons für Spotify, Amazon Music und Spreaker
- E-Mail-Button
- Navigation: Start / Folgen / Bilder / Fakten / Mehr

## Voraussetzungen
Installiere **Android Studio**. Die aktuelle stabile Version ist laut Android Developers Android Studio Quail 3 (2026.1.3 Patch 1). Das Projekt verwendet Android Gradle Plugin 9.3.0 und Gradle 9.5.0.

## Projekt öffnen
1. ZIP-Datei entpacken.
2. Android Studio starten.
3. **Open** auswählen.
4. Den Ordner `Josiah_Bruder_Podcast_App` auswählen.
5. Warten, bis Gradle synchronisiert wurde.
6. Ein Android-Handy per USB verbinden oder einen Emulator starten.
7. Oben auf **Run ▶** drücken.

## APK erstellen
In Android Studio:
**Build → Build APK(s)**

Android Studio erstellt die APK anschließend im Projekt unter:
`app/build/outputs/apk/debug/`

Die offizielle Android-Dokumentation beschreibt ebenfalls den APK-Build über **Build → Build APK(s)**.

## Selbst bearbeiten
Die wichtigsten Stellen:
- Texte/Seiten: `app/src/main/java/com/josiahbruder/podcast/MainActivity.java`
- Fotos: `app/src/main/res/drawable/`
- App-Name: `app/src/main/res/values/strings.xml`
- Farben: oben in `MainActivity.java` (pink, blue, purple, cyan)

### Wichtig
Die angegebenen 75+ Folgen sind aktuell Beispiel-Einträge. Die echten Folgentitel und direkten Links kannst du später in `MainActivity.java` ersetzen.

Die App ist absichtlich ohne zusätzliche externe UI-Bibliotheken aufgebaut, damit sie möglichst einfach zu öffnen und zu verändern ist.
